 <?php if ( is_active_sidebar( 'sidebar-primary' ) )
	{ ?>
<div class="col-md-4 scoreline-sidebar">
<?php dynamic_sidebar( 'sidebar-primary' );	?>
	
</div>	<?php } ?>