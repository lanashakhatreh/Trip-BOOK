=== Travel Ultimate ===

Contributors: themepalace
Tags: translation-ready, custom-background, theme-options, custom-menu, threaded-comments, featured-images, footer-widgets, left-sidebar, editor-style, right-sidebar, full-width-template, two-columns, three-columns, grid-layout, custom-colors, custom-header, custom-logo, featured-image-header, blog, portfolio, entertainment

Requires at least: 4.7
Tested up to: 5.0.2
Stable tag: 1.0.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Travel Ultimate is a splendid and highly responsive WordPress theme for any kind of travel agencies, tour operators or travel business owner. It offer various flexibility and possibilities to setup destinations and tour packages. Travel business owner can show services,booking form, blog, testimonial and other aspects of company. Besides that, it can also be used as a portfolio page for solo travelers or travel guide.  The theme is beautifully crafted, clean, easy to use, responsive, features different layouts with sidebar position and allows unlimited color selection. It has been designed for everybody with or without previous coding experience to effectively and helps to speedily put together polished, professional quality websites without having to so much as peek at a single line of code.
== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

Travel Ultimate WordPress Theme, Copyright 2018 Theme Palace
Link: https://themepalace.com/downloads/tr

HTML5-Shiv is Licensed under the MIT and GPL licenses
    https://code.google.com/p/html5shiv/

Slick Version - 1.6.0
	Source: http://github.com/kenwheeler/slick
	License: The MIT License (MIT) copyright (c) 2013-2016
	license Url : https://github.com/kenwheeler/slick/blob/master/LICENSE

Simple Fontawesome IconPicker
	Source: https://github.com/aumkarthakur/simple-fontawesome-iconpicker
	License: MIT License Copyright (c) 2016 aumkarthakur
	license Url : https://github.com/aumkarthakur/simple-fontawesome-iconpicker/blob/master/LICENSE

Font Awesome 4.7.0 by @davegandy
	License: http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
	Source: http://fontawesome.io

Font Awesome font is licensed under the SIL OFL 1.1:
	License: https://github.com/FortAwesome/Font-Awesome#license
    http://scripts.sil.org/OFL

Chosen Select - 1.4.2
	Source: https://github.com/harvesthq/chosen
	License: The MIT License (MIT) copyright (c) 2011-2015
	license Url : https://github.com/harvesthq/chosen/blob/master/LICENSE.md

Jquery Match Height - 0.7.2
	Source: https://github.com/liabru/jquery-match-height
	License: The MIT License (MIT) Copyright (c) 2014 Liam Brummitt
	license Url : https://github.com/liabru/jquery-match-height/blob/master/LICENSE

Breadcrumb Trail - 1.0.0
	Source: https://github.com/matthieua/WOW
	License: GNU General Public License, version 2
	license Url : http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

== Images Screenshot ==

Header image
License: CC0 1.0 Universal (CC0 1.0)
https://pixabay.com/en/astronomy-beautiful-blue-bright-2297212/

License: CC0 1.0 Universal (CC0 1.0)
https://pixabay.com/en/bridge-wood-architecture-water-usa-1525326/

Unless otherwise specified, all the theme images are created by us and licensed under the same license as the theme is.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

* Contact Form 7
	Contact Form 7 is recommended to use for contact forms for contact page.

* One Click Demo Import
	One Click Demo Import is recommended to extract demo data for initial setup.

* WP Travel
	WP Travel is recommended to use for travel engine in this theme.

== Changelog ==

= 1.0.0 - Feb 28 2018 =
* Initial release

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)

* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)

* SVG Icons function https://github.com/WordPress/twentyseventeen (C) 2016 WordPress.org, [GNU GPL, version 2 or later ( http://www.gnu.org/licenses/old-licenses/gpl-2.0.html )

* class-tgm-plugin-activation.php https://github.com/TGMPA/TGM-Plugin-Activation [GNU General Public License v2.0]
