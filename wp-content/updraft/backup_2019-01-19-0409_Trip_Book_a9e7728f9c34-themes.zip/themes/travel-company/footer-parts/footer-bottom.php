<div class="footer-bottom">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="bottom-inner">
						<div class="row">
							<div class="col-lg-8 col-md-8 col-12">
								<!-- Copyright -->
								<div class="copyright"> 
									<p><?php esc_html_e('&copy; All Right Reserved ','travel-company');  echo  esc_html(date('Y'));?> <a href="<?php echo esc_url(home_url());?>"><?php esc_html(bloginfo('name')); ?></a></p>
								</div>
								<!--/ End Copyright -->
							</div>
							<div class="col-lg-4 col-md-4 col-12">
								<!-- Social -->
								  <?php travel_company_footer_social_links();?>
								<!--/ End Social -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>